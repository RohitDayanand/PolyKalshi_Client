"use client"

import { useMarketContext } from "@/context/market-context"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { PlusCircle } from "lucide-react"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"

interface MarketListProps {
  platform: "polymarket" | "kalshi"
}

export function MarketList({ platform }: MarketListProps) {
  const { searchResults, subscribeToMarket } = useMarketContext()

  const results = searchResults[platform] || []

  if (results.length === 0) {
    return (
      <Card>
        <CardContent className="p-4 text-center text-muted-foreground">
          {searchResults.loading ? "Searching..." : "No markets found. Try searching for a market."}
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardContent className="p-2">
        <ScrollArea className="h-[400px]">
          <div className="space-y-2 p-2">
            {results.map((market) => (
              <div key={market.id} className="flex items-start justify-between p-2 rounded-md hover:bg-muted">
                <div className="space-y-1">
                  <div className="font-medium text-sm">{market.title}</div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-xs">
                      {market.category}
                    </Badge>
                    <span className="text-xs text-muted-foreground">Vol: ${market.volume.toLocaleString()}</span>
                  </div>
                </div>
                <Button size="icon" variant="ghost" onClick={() => subscribeToMarket(platform, market)}>
                  <PlusCircle className="h-4 w-4" />
                  <span className="sr-only">Subscribe</span>
                </Button>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}
