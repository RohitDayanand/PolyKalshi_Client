"use client"

import type React from "react"

import { useState } from "react"
import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { useMarketContext } from "@/context/market-context"

interface MarketSearchProps {
  platform: "polymarket" | "kalshi"
}

export function MarketSearch({ platform }: MarketSearchProps) {
  const [query, setQuery] = useState("")
  const { searchMarkets } = useMarketContext()

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    searchMarkets(platform, query)
  }

  return (
    <form onSubmit={handleSearch} className="relative">
      <Input
        type="text"
        placeholder={`Search ${platform} markets...`}
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        className="pr-10"
      />
      <Button type="submit" size="icon" variant="ghost" className="absolute right-0 top-0 h-full">
        <Search className="h-4 w-4" />
        <span className="sr-only">Search</span>
      </Button>
    </form>
  )
}
