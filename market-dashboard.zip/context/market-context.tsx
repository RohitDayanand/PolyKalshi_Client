"use client"

import { createContext, useContext, useState, type ReactNode } from "react"
import type { Market, SearchResults } from "@/types/market"
import { mockPolymarketSearch, mockKalshiSearch } from "@/lib/mock-data"

interface MarketContextType {
  searchResults: {
    polymarket: Market[]
    kalshi: Market[]
    loading: boolean
  }
  subscribedMarkets: Market[]
  activeMarkets: Market[]
  searchMarkets: (platform: "polymarket" | "kalshi", query: string) => void
  subscribeToMarket: (platform: "polymarket" | "kalshi", market: Market) => void
  unsubscribeFromMarket: (marketId: string) => void
  setActiveMarkets: (markets: Market[]) => void
}

const MarketContext = createContext<MarketContextType | undefined>(undefined)

export function MarketProvider({ children }: { children: ReactNode }) {
  const [searchResults, setSearchResults] = useState<SearchResults>({
    polymarket: [],
    kalshi: [],
    loading: false,
  })

  const [subscribedMarkets, setSubscribedMarkets] = useState<Market[]>([])
  const [activeMarkets, setActiveMarkets] = useState<Market[]>([])

  const searchMarkets = async (platform: "polymarket" | "kalshi", query: string) => {
    setSearchResults((prev) => ({ ...prev, loading: true }))

    // Simulate API call with mock data
    setTimeout(() => {
      if (platform === "polymarket") {
        const results = mockPolymarketSearch(query)
        setSearchResults((prev) => ({
          ...prev,
          polymarket: results,
          loading: false,
        }))
      } else {
        const results = mockKalshiSearch(query)
        setSearchResults((prev) => ({
          ...prev,
          kalshi: results,
          loading: false,
        }))
      }
    }, 500)
  }

  const subscribeToMarket = (platform: "polymarket" | "kalshi", market: Market) => {
    // Check if already subscribed
    if (subscribedMarkets.some((m) => m.id === market.id)) {
      return
    }

    const marketWithPlatform = {
      ...market,
      platform,
    }

    setSubscribedMarkets((prev) => [...prev, marketWithPlatform])
  }

  const unsubscribeFromMarket = (marketId: string) => {
    setSubscribedMarkets((prev) => prev.filter((market) => market.id !== marketId))
    setActiveMarkets((prev) => prev.filter((market) => market.id !== marketId))
  }

  return (
    <MarketContext.Provider
      value={{
        searchResults,
        subscribedMarkets,
        activeMarkets,
        searchMarkets,
        subscribeToMarket,
        unsubscribeFromMarket,
        setActiveMarkets,
      }}
    >
      {children}
    </MarketContext.Provider>
  )
}

export function useMarketContext() {
  const context = useContext(MarketContext)
  if (context === undefined) {
    throw new Error("useMarketContext must be used within a MarketProvider")
  }
  return context
}
